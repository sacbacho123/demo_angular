import { Component, OnInit } from '@angular/core';
import { DataService } from './../../_Service/data.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  constructor( public data:DataService, public route: ActivatedRoute) { }
  order:any;
  datas:any;
  ngOnInit(): void {
    let preFolder = this.route.snapshot.params['id'];
    this.order=preFolder;
    this.datas =this.data.getAll();
  }

}
