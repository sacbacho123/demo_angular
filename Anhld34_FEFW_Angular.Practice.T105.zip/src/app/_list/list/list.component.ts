import { Component, OnInit } from '@angular/core';
import { DataService } from './../../_Service/data.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
})
export class ListComponent implements OnInit {
  constructor(public data: DataService) {}

  datas: any;

  ngOnInit(): void {
    this.datas = this.data.getAll();
  }
}
