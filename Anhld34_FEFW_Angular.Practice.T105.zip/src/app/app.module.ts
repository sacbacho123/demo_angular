import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CardComponent } from './_cardView/card/card.component';
import { ListComponent } from './_list/list/list.component';
import { DetailComponent } from './_Detail/detail/detail.component';
import { OrderComponent } from './_Oders/order/order.component';
import { CustomerComponent } from './_Customer/customer/customer.component';

@NgModule({
  declarations: [
    AppComponent,
    CardComponent,
    ListComponent,
    DetailComponent,
    OrderComponent,
    CustomerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
