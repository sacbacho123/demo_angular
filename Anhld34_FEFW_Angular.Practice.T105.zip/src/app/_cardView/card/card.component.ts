import { Component, OnInit } from '@angular/core';
import {DataService} from './../../_Service/data.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  constructor(public data: DataService,public route: ActivatedRoute) { 
    
  }
  datas:any;

  ngOnInit(): void {
    this.datas = this.data.getAll()
  }

}
