import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CardComponent } from './_cardView/card/card.component';
import { ListComponent } from './_list/list/list.component';
import { DetailComponent } from './_Detail/detail/detail.component';
import { OrderComponent } from './_Oders/order/order.component';
import { CustomerComponent } from './_Customer/customer/customer.component';

const routes: Routes = [
  { path: '', component: CustomerComponent },
  {
    path: 'customer',
    component: CustomerComponent,
  },
  { path: 'list', component: ListComponent },
  { path: 'card', component: CardComponent },
  { path: 'customer/:id/detail', component: DetailComponent },
  { path: 'customer/:id/order', component: OrderComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
export const routingComponents = [
  CardComponent,
  ListComponent,
  DetailComponent,
  OrderComponent,
  CustomerComponent,
];
